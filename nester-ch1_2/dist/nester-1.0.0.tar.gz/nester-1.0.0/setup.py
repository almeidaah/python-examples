from distutils.core import setup

setup(
    name         = 'nester',
    version      = '1.0.0',
    py_modules   = ['nester'],
    author       = 'falmeidapy',
    author_email = 'almeidascvn@gmail.com',
    url          = 'fernandoalmeida.esy.es',
    description  = 'Meu primeiro módulo Python - @almeidajava'
)

